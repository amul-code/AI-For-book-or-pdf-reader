# AI-FOR-book-or-pdf-reading
This is an Ai for reading books or pdf by giving command play book, play pdf, tell story,and you can also read from wikipedia or google by just saying "play book name on wikipesdia or google".
